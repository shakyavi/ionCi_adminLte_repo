﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'he', {
	bold: 'מודגש',
	italic: 'נטוי',
	strike: 'כתיב מחוק',
	subscript: 'כתיב תחתון',
	superscript: 'כתיב עליון',
	underline: 'קו תחתון'
} );
