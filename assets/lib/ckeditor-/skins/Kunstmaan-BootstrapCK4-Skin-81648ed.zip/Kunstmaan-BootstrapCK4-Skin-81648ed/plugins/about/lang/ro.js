﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'ro', {
	copy: 'Copyright &copy; $1. Toate drepturile rezervate.',
	dlgTitle: 'Despre CKEeditor',
	help: 'Citește  $1 pentru ajutor.',
	moreInfo: 'Pentru informații despre licență, vă rugăm vizitați web site-ul nostru:',
	title: 'Despre CKEditor',
	userGuide: 'CKEditor Ghid Utilizator'
} );
