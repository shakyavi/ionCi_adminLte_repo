﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'si', {
	ltr: 'වගන්ති දිශාව වමේ සිට දකුණට',
	rtl: 'වගන්ති දිශාව  දකුණේ සිට වමට'
} );
